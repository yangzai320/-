# Retail Order KPI Analysis Project

This is a basic data analytics portfolio project built with the public UCI Online Retail transaction dataset.

## Dataset
- Source: UCI Machine Learning Repository, Online Retail dataset.
- Period: 2010-12-01 to 2011-12-09.
- Raw records: 541,909 rows.
- Key fields: invoice number, product code, product description, quantity, invoice date, unit price, customer ID, country.

## What this project does
1. Cleans cancelled orders, non-positive quantities, and invalid prices.
2. Builds sales KPIs with SQL, including revenue, orders, customers, units sold, and average order value.
3. Creates simple RFM customer segments with Python.
4. Exports Power BI-ready CSV files.
5. Generates charts for a short business analysis report.

## How to run
```bash
pip install -r requirements.txt
python src/run_analysis.py
```

## Main outputs
- `powerbi_data/monthly_kpis.csv`
- `powerbi_data/country_performance.csv`
- `powerbi_data/product_performance.csv`
- `powerbi_data/customer_rfm_segments.csv`
- `powerbi_data/monthly_repeat_rate.csv`
- `sql/business_kpi_queries.sql`
- `output/retail_order_analysis_report.md`
